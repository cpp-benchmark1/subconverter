﻿
#if __COVERITY__
#if !defined(COVERITY_COMPAT_cd9c257485cf43c5a27194bd8ed79d54)
#define COVERITY_COMPAT_cd9c257485cf43c5a27194bd8ed79d54
#pragma builtin begin


#pragma builtin end
#endif /* COVERITY_COMPAT_cd9c257485cf43c5a27194bd8ed79d54 */
#endif /* __COVERITY__ */
