﻿
#if __COVERITY__
#if !defined(COVERITY_COMPAT_695650ade534df6eff1ba37b2dfff7d7)
#define COVERITY_COMPAT_695650ade534df6eff1ba37b2dfff7d7
#pragma builtin begin


#pragma builtin end
#endif /* COVERITY_COMPAT_695650ade534df6eff1ba37b2dfff7d7 */
#endif /* __COVERITY__ */
